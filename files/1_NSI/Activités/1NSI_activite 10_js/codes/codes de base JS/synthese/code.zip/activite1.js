/* ///////////// 1.Boite de dialogue ///////////// */


function boite() {
	var x=document.getElementById("texte1");
	var texte = prompt("Saississez votre texte");
	/* à compléter */
	
}

/* //////////////// 2.Range slider ///////////////// */

function glissiere() {



}



/* /////////// 3.Modifier le style (couleur)  //////// */

function changeCouleur() {
	
	
	
}



/* ////////// 4.Modifier le style (taille) ///////// */


function tailleImage(Largeur, hauteur) {
	
	
	
}


/* //////////////// 5.Nombre entier aléatoire /////////// */


/*  Math.floor(x) retourne le plus grand entier qui est inférieur ou égal à un nombre x   */

function randomNb(max) {
	
	// à compléter
}

function afficheNb() {
	
	// à compléter
	
}


/* /////////////////// 6.Couleur de fond /////////////// */


function randomCouleur() {
	var color = "rgb(" + randomNb(256) + "," + randomNb(256) + "," + randomNb(256) + ")";
	return color;
}

function affichage() {
	var x = document.body;
	var y = document.getElementById("texte5");
	// A compléter
}






