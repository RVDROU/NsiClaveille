/////////////////////////////////////////////////////////////

/*EXEMPLE:*/

// var r = document.getElementById('slider_red');  r contient la valeur de la glissière rouge
// var r_dec = parseInt(r.value);       conversion  en type entier décimal
// var r_hexa = parseInt(r.value).toString(16);   conversion au format hexadécimal





/*Fonction de padding: Affiche par exemple "0F" à la place de "F"*/
function pad(n) {
		   if (n.length < 2) {return '0'+n}
		   else{return n;}
		}




////////////////////////////////////////////////////////////





