import manipulationImage  

#Affiche le negatif d'une image
img=ouvrirImage("AliceNB.png")
hauteur=len(img)
largeur=len(img[0])
for ligne in range(int((hauteur/2))-10,int((hauteur/2))+10) :
    for colonne in range(largeur) :
        img[ligne][colonne]
        
            
		
afficherImage(img)