from manipulationImage import * 

#Affiche le negatif d'une image
img=ouvrirImage("nb.png")
hauteur=len(img)
largeur=len(img[0])
for ligne in range(hauteur) :
    for colonne in range(largeur) :
        if img[ligne][colonne]<127 :
            img[ligne][colonne]=0
        else :
            img[ligne][colonne]=255
             
		
afficherImage(img)