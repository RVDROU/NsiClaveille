# -*- coding: utf-8 -*-
"""
Created on Sun Sep 22 19:21:39 2019

@author: herve
"""

from manipulationImage import *  #Importer la bibliothèque traitement		
img=ouvrirImage("imageSimple.png") #Charger l'image dans img img.	
	#img->liste contenant la nuance de gris de chaque pixel			
afficherImage(img)