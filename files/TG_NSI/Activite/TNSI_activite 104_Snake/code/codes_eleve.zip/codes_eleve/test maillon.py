from maillon import Maillon
from random import randint

maListe= Maillon(10,None)

#Construit une liste chaînee maListe de 10 maillons contenant des valeurs aleatoires

for i in range(10) : maListe = Maillon(randint(0,100),maListe)    
 
#########################   Fonctions a completer   ###################################        
def supprime_queue(m) :
   pass
        
    
def longueur_liste(m) : #Q7
    if ________ : return 1
    else : return 1+longueur_liste(_______)
        

def test_valeur(val,m) :
    pass
        

        
        